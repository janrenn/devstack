
-- PURGE

DELETE FROM cfwp_posts WHERE post_type = "revision";

DELETE FROM cfwp_postmeta WHERE meta_key = '_edit_lock';
DELETE FROM cfwp_postmeta WHERE meta_key = '_edit_last';
DELETE FROM cfwp_postmeta WHERE meta_key = '_encloseme';

-- remove non-existent post's meta orphans
DELETE pm FROM cfwp_postmeta pm LEFT JOIN cfwp_posts wp ON wp.ID = pm.post_id WHERE wp.ID IS NULL;

DELETE FROM cfwp_options WHERE option_name LIKE ('%_transient_%');
UPDATE cfwp_options SET option_value = '' WHERE option_name = 'recently_edited';

DELETE FROM cfwp_posts WHERE post_status = 'auto-draft';


-- plugin specific
-- TRUNCATE cfwp_btev_events;
-- TRUNCATE cfwp_wsal_metadata;
-- TRUNCATE cfwp_wsal_occurrences;



-- DEPLOYMENT @see http://codex.wordpress.org/Changing_The_Site_URL
-- LOCAL TO PROD

UPDATE cfwp_options SET option_value = REPLACE(option_value,'//wpx.test','//prod.example.com') WHERE option_name IN('siteurl','home','ossdl_off_cdn_url');
UPDATE cfwp_posts SET guid = REPLACE(guid,'//wpx.test/','//prod.example.com/');
UPDATE cfwp_posts SET post_content = REPLACE(post_content,'//wpx.test/','//prod.example.com/');
UPDATE cfwp_postmeta SET meta_value = REPLACE( meta_value, '//wpx.test/', '//prod.example.com/' ) WHERE meta_value NOT LIKE '%:{%';


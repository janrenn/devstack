
-- PURGE

DELETE FROM wp_posts WHERE post_type = "revision";

DELETE FROM wp_postmeta WHERE meta_key = '_edit_lock';
DELETE FROM wp_postmeta WHERE meta_key = '_edit_last';
DELETE FROM wp_postmeta WHERE meta_key = '_encloseme';

-- remove non-existent post's meta orphans
DELETE pm FROM wp_postmeta pm LEFT JOIN wp_posts wp ON wp.ID = pm.post_id WHERE wp.ID IS NULL;


DELETE FROM wp_options WHERE option_name LIKE ('%_transient_%');
UPDATE wp_options SET option_value = '' WHERE option_name = 'recently_edited';

DELETE FROM wp_posts WHERE post_status = 'auto-draft';

-- DELETE FROM wp_posts WHERE post_type = 'nav_menu_item' AND post_status = 'draft';

-- UPDATE wp_posts SET post_date = '2013-05-24 06:00:00' WHERE post_type = 'page';
-- UPDATE wp_posts SET post_date_gmt = '2013-05-24 13:00:00' WHERE post_type = 'page';


-- plugin specific
-- CREATE TABLE IF NOT EXISTS wp_btev_events;
-- TRUNCATE wp_btev_events;
-- TRUNCATE wp_wsal_metadata;
-- TRUNCATE wp_wsal_occurrences;

DELETE FROM wp_usermeta WHERE meta_key = 'session_tokens' OR meta_key = 'reset_pass_hash' OR meta_key = 'reset_pass_hash_token';
UPDATE wp_usermeta SET meta_value = '0' WHERE meta_key = 'password_rst_attempts';

1. Vytvoření nového certifikátu pro lokální doménu
================================================

1.1. Vytvoření certifikátu
----------------------------

Vytvoříme složku pro projekt `wpxCA/example`

Vygenerujeme privátní klíč:

```bash
openssl genrsa -out example/example.key 2048
```

...  a žádost o certifikát:

```bash
openssl req -new -key example/example.key -out example/example.csr
```

Do žádosti stačí vyplnit následující, zbytek vč. *challenge password* je možno
nechat prázdný.

* Organization Name: example
* Common Name: example
* Email Address: : example@cyberfox.cz

Dále vytvoříme soubor `wpxCA/example/example.ext` s následujícím obsahem, 
kde DNS je lokální hostname.

```
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
subjectAltName = @alt_names

[alt_names]
DNS.1 = example
IP.1 = 127.0.0.1
```

A s použitím předchozího vygenerujeme certifikát:

```bash
openssl x509 -req -in example/example.csr -CA wpxCA.pem -CAkey wpxCA.key -CAcreateserial -out example/example.crt -days 1825 -sha256 -extfile example/example.ext
```

Heslo: ****

1.2. Troubleshooting
----------------------------

Tuhne na Win7/10 cli při posledním příkazu? Použij `winpty` https://stackoverflow.com/questions/3758167/openssl-command-hangs

```bash
winpty openssl x509 -req -in example/example.csr -CA wpxCA.pem -CAkey wpxCA.key -CAcreateserial -out example/example.crt -days 1825 -sha256 -extfile example/example.ext
```

1.3. Použití certifikátu
----------------------------

Vytvořený certifikát a klíč je vhodné umístit do neveřejné složky projektu a přidat
do repozitáře.

Server nasměrujeme na certifikát ve vhost souboru a restartujeme Apache:

```apache
<IfModule ssl_module>
	<VirtualHost *:443>
        (...)
		SSLEngine on
		SSLCertificateFile "c:/dev_storage/webs/example/trunk/cert/example/example.crt"
		SSLCertificateKeyFile "c:/dev_storage/webs/example/trunk/cert/example/example.key"
	</VirtualHost>
</IfModule>
```

2. Instalace kořenového certifikátu
===================================

Aby prohlížeče akceptovaly certifikáty pro jednotlivé domény, je třeba zajistit, 
aby systém nebo aplikace důvěřovaly kořenovému certifikátu vydavatele **WPXpress CA**. 
Situace je podobná jako u certifikační autority **ca.cyberfox.local**, jak je popsáno
v návodu http://home.cyberfox.local/cs/manualy/hardware-a-infrastruktura/uzivani-lokalnich-serveru/migrace-2016

2.1. Konfigurace Windows
------------------------

**2.1.1. Windows certifikáty**

* Otevřít soubor certifikátu **wpxCA.crt** a kliknout na volbu "Nainstalovat certifikát"
* V průvodci ručně vybrat úložiště na "Důvěryhodné certifikační autority" a dokončit import

**2.1.2. TortoiseGit / Git**

Přidat kompletní obsah souboru certifikátu **wpxCA.pem** na konec souboru `c:\Program Files\Git\mingw64\ssl\certs\ca-bundle.crt`

**2.1.3. Firefox / Chrome**

* Přidat certifikát **wpxCA.crt** nebo **wpxCA.pem** do seznamu důvěryhodných kořenových certifikátů
 - FF: Možnosti / Rozšířené / Certifikáty / Certifikáty / Importovat
 - CH: Nastavení / Zobrazit rozšířené možnosti / Spravovat certifikáty / Importovat

2.2. Konfigurace Mac OSX
------------------------

* Importovat **wpxCA.pem** do klíčenky (keychain)
* Označit importovaný certifikát za důvěryhodný

2.3. Konfigurace Linux
------------------------------

* Zkopírovat **wpxCA.pem** do `/usr/local/share/ca-certificates/`
* Spustit příkaz `update-ca-certificates`

3. Odkazy
==========

* https://deliciousbrains.com/ssl-certificate-authority-for-local-https-development/
* https://stackoverflow.com/questions/7580508/getting-chrome-to-accept-self-signed-localhost-certificate
* http://home.cyberfox.local/cs/manualy/hardware-a-infrastruktura/uzivani-lokalnich-serveru/migrace-2016